package com.example.application.util;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

public class ProfileManager {
    
    private static final String PREFS_NAME = "offset_profiles";
    private static final String KEY_PROFILES = "profiles";
    
    private SharedPreferences prefs;
    
    public ProfileManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    public List<GameProfile> getAllProfiles() {
        String json = prefs.getString(KEY_PROFILES, "");
        List<GameProfile> profiles = new ArrayList<GameProfile>();
        
        if (json.isEmpty()) {
            return profiles;
        }
        
        String[] profileData = json.split("\\|\\|\\|");
        for (String data : profileData) {
            if (data.isEmpty()) continue;
            
            String[] parts = data.split("\\|");
            if (parts.length >= 2) {
                String name = parts[0];
                List<OffsetEntry> entries = new ArrayList<OffsetEntry>();
                
                for (int i = 1; i < parts.length; i++) {
                    String[] entry = parts[i].split("::");
                    if (entry.length >= 2) {
                        entries.add(new OffsetEntry(entry[0], entry[1]));
                    }
                }
                
                if (!entries.isEmpty()) {
                    profiles.add(new GameProfile(name, entries));
                }
            }
        }
        
        return profiles;
    }
    
    public void saveProfile(GameProfile profile) {
        List<GameProfile> profiles = getAllProfiles();
        
        for (int i = 0; i < profiles.size(); i++) {
            if (profiles.get(i).name.equals(profile.name)) {
                profiles.set(i, profile);
                saveAll(profiles);
                return;
            }
        }
        
        profiles.add(profile);
        saveAll(profiles);
    }
    
    public void deleteProfile(String profileName) {
        List<GameProfile> profiles = getAllProfiles();
        
        for (int i = 0; i < profiles.size(); i++) {
            if (profiles.get(i).name.equals(profileName)) {
                profiles.remove(i);
                saveAll(profiles);
                return;
            }
        }
    }
    
    private void saveAll(List<GameProfile> profiles) {
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < profiles.size(); i++) {
            GameProfile p = profiles.get(i);
            if (i > 0) sb.append("|||");
            
            sb.append(p.name);
            for (OffsetEntry e : p.entries) {
                sb.append("|").append(e.className).append("::").append(e.methodName);
            }
        }
        
        prefs.edit().putString(KEY_PROFILES, sb.toString()).apply();
    }
    
    public void clearAll() {
        prefs.edit().remove(KEY_PROFILES).apply();
    }
    
    public static class GameProfile {
        public String name;
        public List<OffsetEntry> entries;
        
        public GameProfile(String name, List<OffsetEntry> entries) {
            this.name = name;
            this.entries = entries;
        }
    }
    
    public static class OffsetEntry {
        public String className;
        public String methodName;
        
        public OffsetEntry(String className, String methodName) {
            this.className = className;
            this.methodName = methodName;
        }
        
        public String toString() {
            return className + "." + methodName;
        }
    }
}
