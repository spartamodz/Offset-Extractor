package com.example.application.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.example.application.R;
import com.example.application.common.activity.BaseActivity;
import com.example.application.util.OffsetFinder;
import com.example.application.util.ProfileManager;
import com.example.application.util.SoInfoExtractor;
import com.example.application.util.ToastHelper;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int FILE_PICKER_DUMP = 101;
    private static final int FILE_PICKER_SO = 102;
    private static final int PROFILE_MANAGER_REQUEST = 103;
    private static final int EXPORT_RESULT_REQUEST = 104;
    
    private Button btnProfiles;
    private Button btnSelectDump;
    private Button btnSelectSo;
    private Button btnFindOffset;
    private Button btnCopy;
    private Button btnExportResult;
    private EditText edtClassName;
    private EditText edtMethodName;
    private TextView txtSelectedFile;
    private TextView txtProfileInfo;
    private TextView txtResult;
    
    private Uri dumpFileUri;
    private Uri soFileUri;
    private OffsetFinder offsetFinder;
    private Handler mainHandler;
    private boolean isSearching;
    
    private ProfileManager profileManager;
    private List<ProfileManager.OffsetEntry> currentProfile;
    private int currentProfileIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainHandler = new Handler(Looper.getMainLooper());
        profileManager = new ProfileManager(this);
        currentProfile = new ArrayList<ProfileManager.OffsetEntry>();

        btnProfiles = (Button) findViewById(R.id.btnProfiles);
        btnProfiles.setOnClickListener(this);
        
        btnSelectDump = (Button) findViewById(R.id.btnSelectDump);
        btnSelectDump.setOnClickListener(this);
        
        btnSelectSo = (Button) findViewById(R.id.btnSelectSo);
        btnSelectSo.setOnClickListener(this);
        
        btnFindOffset = (Button) findViewById(R.id.btnFindOffset);
        btnFindOffset.setOnClickListener(this);
        
        btnCopy = (Button) findViewById(R.id.btnCopy);
        btnCopy.setOnClickListener(this);
        
        btnExportResult = (Button) findViewById(R.id.btnExportResult);
        btnExportResult.setOnClickListener(this);
        
        edtClassName = (EditText) findViewById(R.id.edtClassName);
        edtMethodName = (EditText) findViewById(R.id.edtMethodName);
        txtSelectedFile = (TextView) findViewById(R.id.txtSelectedFile);
        txtProfileInfo = (TextView) findViewById(R.id.txtProfileInfo);
        txtResult = (TextView) findViewById(R.id.txtResult);
        
        setupResultText();
    }

    private void setupResultText() {
        txtResult.setTextIsSelectable(true);
        txtResult.setClickable(true);
        txtResult.setLongClickable(true);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnProfiles) {
            openProfileManager();
        } else if (id == R.id.btnSelectDump) {
            if (checkStoragePermission()) {
                openFilePicker(FILE_PICKER_DUMP);
            } else {
                requestStoragePermission();
            }
        } else if (id == R.id.btnSelectSo) {
            if (checkStoragePermission()) {
                openFilePicker(FILE_PICKER_SO);
            } else {
                requestStoragePermission();
            }
        } else if (id == R.id.btnFindOffset) {
            findOffset();
        } else if (id == R.id.btnCopy) {
            copyResult();
        } else if (id == R.id.btnExportResult) {
            exportResult();
        }
    }

    private void openProfileManager() {
        Intent intent = new Intent(this, ProfileManagerActivity.class);
        startActivityForResult(intent, PROFILE_MANAGER_REQUEST);
    }

    private void exportResult() {
        String text = txtResult.getText().toString();
        if (text == null || text.isEmpty() || text.contains("Select dump.cs")) {
            ToastHelper.showErrorToast(this, "Nothing to export");
            return;
        }
        
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "offsets_" + timestamp + ".txt";
        
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        startActivityForResult(intent, EXPORT_RESULT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == EXPORT_RESULT_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    if (os != null) {
                        OutputStreamWriter writer = new OutputStreamWriter(os);
                        writer.write(txtResult.getText().toString());
                        writer.close();
                        ToastHelper.showSuccessToast(this, "Exported to " + uri.getLastPathSegment());
                    }
                } catch (Exception e) {
                    ToastHelper.showErrorToast(this, "Export failed: " + e.getMessage());
                }
            }
            return;
        }
        
        if (requestCode == PROFILE_MANAGER_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            String profileName = data.getStringExtra("profile_name");
            String entriesStr = data.getStringExtra("entries");
            
            if (entriesStr != null) {
                currentProfile.clear();
                String[] entries = entriesStr.split(",");
                for (String entry : entries) {
                    String[] parts = entry.split("::");
                    if (parts.length >= 2) {
                        currentProfile.add(new ProfileManager.OffsetEntry(parts[0], parts[1]));
                    }
                }
                
                txtProfileInfo.setText("Profile loaded: " + profileName + " (" + currentProfile.size() + " offsets)");
                txtProfileInfo.setVisibility(View.VISIBLE);
                
                if (!currentProfile.isEmpty()) {
                    edtClassName.setText(currentProfile.get(0).className);
                    edtMethodName.setText(currentProfile.get(0).methodName);
                }
                
                ToastHelper.showSuccessToast(this, "Loaded " + currentProfile.size() + " offsets from profile");
            }
            return;
        }
        
        if (resultCode == RESULT_OK && data != null) {
            Uri fileUri = data.getData();
            if (fileUri != null) {
                String fileName = getFileName(fileUri);
                
                if (requestCode == FILE_PICKER_DUMP) {
                    dumpFileUri = fileUri;
                    txtSelectedFile.setText("dump.cs: " + fileName);
                    ToastHelper.showSuccessToast(this, "Loaded: " + fileName);
                } else if (requestCode == FILE_PICKER_SO) {
                    soFileUri = fileUri;
                    txtSelectedFile.setText("libil2cpp.so: " + fileName);
                    ToastHelper.showInfoToast(this, "Analyzing libil2cpp.so...");
                    analyzeSoFile(fileUri, fileName);
                }
            }
        }
    }

    private void analyzeSoFile(final Uri fileUri, final String fileName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                SoInfoExtractor extractor = new SoInfoExtractor(getContentResolver(), fileUri);
                final SoInfoExtractor.SoInfoResult result = extractor.extractInfo();
                
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (result != null) {
                            String soInfo = result.getFormattedInfo();
                            txtResult.setText(soInfo);
                            if (result.hasUnityVersion()) {
                                ToastHelper.showSuccessToast(MainActivity.this, 
                                    "Unity " + result.unityVersion + " detected!");
                            } else {
                                ToastHelper.showSuccessToast(MainActivity.this, 
                                    "libil2cpp.so analyzed!");
                            }
                        } else {
                            ToastHelper.showErrorToast(MainActivity.this, 
                                "Could not extract info from .so file");
                        }
                    }
                });
            }
        }).start();
    }

    private void findOffset() {
        if (isSearching) {
            if (offsetFinder != null) {
                offsetFinder.cancel();
            }
            isSearching = false;
            btnFindOffset.setText("FIND OFFSET");
            txtResult.setText("Search cancelled");
            return;
        }
        
        if (!currentProfile.isEmpty()) {
            scanAllOffsets();
            return;
        }
        
        final String className = edtClassName.getText().toString().trim();
        final String methodName = edtMethodName.getText().toString().trim();
        
        if (className.isEmpty()) {
            edtClassName.setError("Required");
            return;
        }
        
        if (methodName.isEmpty()) {
            edtMethodName.setError("Required");
            return;
        }
        
        if (dumpFileUri == null) {
            txtResult.setText("ERROR: Please select dump.cs file first");
            ToastHelper.showErrorToast(this, "Select dump.cs first");
            return;
        }
        
        findSingleOffset(className, methodName);
    }

    private void findSingleOffset(final String className, final String methodName) {
        isSearching = true;
        btnFindOffset.setText("CANCEL");
        txtResult.setText("Searching...\n\nScanning file, please wait...");
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                offsetFinder = new OffsetFinder(getContentResolver(), dumpFileUri);
                final OffsetFinder.OffsetResult result = offsetFinder.findOffset(className, methodName);
                
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        isSearching = false;
                        btnFindOffset.setText("FIND OFFSET");
                        
                        if (result != null) {
                            txtResult.setText(result.getFormattedInfo());
                            ToastHelper.showSuccessToast(MainActivity.this, "Offset found: " + result.rva);
                        } else {
                            txtResult.setText("NOT FOUND\n\n" + offsetFinder.getLastError());
                            ToastHelper.showErrorToast(MainActivity.this, "Offset not found");
                        }
                    }
                });
            }
        }).start();
    }

    private void scanAllOffsets() {
        if (dumpFileUri == null) {
            txtResult.setText("ERROR: Please select dump.cs file first");
            ToastHelper.showErrorToast(this, "Select dump.cs first");
            return;
        }
        
        isSearching = true;
        btnFindOffset.setText("CANCEL");
        currentProfileIndex = 0;
        
        final StringBuilder results = new StringBuilder();
        results.append("BATCH SCAN RESULTS\n");
        results.append("==================\n\n");
        
        scanNextOffset(results);
    }

    private void scanNextOffset(final StringBuilder results) {
        if (!isSearching) {
            return;
        }
        
        if (currentProfileIndex >= currentProfile.size()) {
            isSearching = false;
            btnFindOffset.setText("FIND OFFSET");
            txtResult.setText(results.toString());
            ToastHelper.showSuccessToast(this, "Batch scan complete!");
            return;
        }
        
        final ProfileManager.OffsetEntry entry = currentProfile.get(currentProfileIndex);
        txtResult.setText("Scanning " + (currentProfileIndex + 1) + "/" + currentProfile.size() + "\n\n" + 
                         entry.className + "." + entry.methodName);
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                OffsetFinder finder = new OffsetFinder(getContentResolver(), dumpFileUri);
                final OffsetFinder.OffsetResult result = finder.findOffset(entry.className, entry.methodName);
                
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        results.append(entry.className).append(".").append(entry.methodName).append("\n");
                        
                        if (result != null) {
                            results.append("  OFFSET: ").append(result.rva).append("\n");
                            results.append("  TYPE: ").append(result.returnType).append("\n");
                        } else {
                            results.append("  NOT FOUND\n");
                        }
                        results.append("\n");
                        
                        currentProfileIndex++;
                        scanNextOffset(results);
                    }
                });
            }
        }).start();
    }

    private void copyResult() {
        String text = txtResult.getText().toString();
        if (text == null || text.isEmpty() || text.contains("Select dump.cs")) {
            ToastHelper.showErrorToast(this, "Nothing to copy");
            return;
        }
        
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText("Offset Result", text);
            clipboard.setPrimaryClip(clip);
            ToastHelper.showSuccessToast(this, "Copied to clipboard!");
        } else {
            ToastHelper.showErrorToast(this, "Clipboard not available");
        }
    }

    private boolean checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.length > 0 
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openFilePicker(FILE_PICKER_DUMP);
        }
    }

    private void openFilePicker(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            String title = requestCode == FILE_PICKER_SO ? "Select libil2cpp.so" : "Select dump.cs";
            startActivityForResult(Intent.createChooser(intent, title), requestCode);
        } catch (Exception e) {
            ToastHelper.showErrorToast(this, "No file manager available");
        }
    }

    private String getFileName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) name = cursor.getString(idx);
                }
                cursor.close();
            }
        }
        if (name == null) {
            name = uri.getPath();
            if (name != null) {
                name = name.substring(name.lastIndexOf('/') + 1);
            }
        }
        return name != null ? name : "Unknown";
    }
}
