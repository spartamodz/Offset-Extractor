package com.example.application.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.example.application.R;
import com.example.application.common.activity.BaseActivity;
import com.example.application.util.ProfileManager;
import com.example.application.util.ToastHelper;

public class ProfileManagerActivity extends BaseActivity {
    
    private static final int IMPORT_PROFILE_REQUEST = 201;
    private static final int BACKUP_PROFILES_REQUEST = 202;
    private static final int RESTORE_PROFILES_REQUEST = 203;
    
    private ListView listView;
    private ProfileAdapter adapter;
    private ProfileManager profileManager;
    private List<ProfileManager.GameProfile> profiles;
    
    private EditText edtProfileName;
    private EditText edtClassName;
    private EditText edtMethodName;
    private LinearLayout entriesLayout;
    
    private List<ProfileManager.OffsetEntry> currentEntries;
    private String currentProfileName;
    private boolean isEditingProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_manager);
        
        profileManager = new ProfileManager(this);
        currentEntries = new ArrayList<ProfileManager.OffsetEntry>();
        profiles = new ArrayList<ProfileManager.GameProfile>();
        isEditingProfile = false;
        
        listView = (ListView) findViewById(R.id.listView);
        edtProfileName = (EditText) findViewById(R.id.edtProfileName);
        edtClassName = (EditText) findViewById(R.id.edtClassName);
        edtMethodName = (EditText) findViewById(R.id.edtMethodName);
        entriesLayout = (LinearLayout) findViewById(R.id.entriesLayout);
        
        Button btnAddEntry = (Button) findViewById(R.id.btnAddEntry);
        btnAddEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addEntry();
            }
        });
        
        Button btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProfile();
            }
        });
        
        Button btnClear = (Button) findViewById(R.id.btnClear);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearForm();
            }
        });
        
        Button btnImport = (Button) findViewById(R.id.btnImport);
        btnImport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                importProfile();
            }
        });
        
        Button btnBackup = (Button) findViewById(R.id.btnBackup);
        btnBackup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backupProfiles();
            }
        });
        
        Button btnRestore = (Button) findViewById(R.id.btnRestore);
        btnRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restoreProfiles();
            }
        });
        
        loadProfiles();
        
        adapter = new ProfileAdapter();
        listView.setAdapter(adapter);
    }
    
    private void importProfile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("text/plain");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "Import Profile"), IMPORT_PROFILE_REQUEST);
        } catch (Exception e) {
            ToastHelper.showErrorToast(this, "No file manager available");
        }
    }
    
    private void backupProfiles() {
        if (profiles.isEmpty()) {
            ToastHelper.showErrorToast(this, "No profiles to backup");
            return;
        }
        
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "offset_profiles_" + timestamp + ".txt";
        
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        startActivityForResult(intent, BACKUP_PROFILES_REQUEST);
    }
    
    private void restoreProfiles() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("text/plain");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "Restore Profiles Backup"), RESTORE_PROFILES_REQUEST);
        } catch (Exception e) {
            ToastHelper.showErrorToast(this, "No file manager available");
        }
    }
    
    private void doBackup(Uri uri) {
        try {
            OutputStream os = getContentResolver().openOutputStream(uri);
            if (os != null) {
                OutputStreamWriter writer = new OutputStreamWriter(os);
                for (int i = 0; i < profiles.size(); i++) {
                    ProfileManager.GameProfile p = profiles.get(i);
                    if (i > 0) writer.write("|||\n");
                    writer.write(p.name + "\n");
                    for (int j = 0; j < p.entries.size(); j++) {
                        ProfileManager.OffsetEntry e = p.entries.get(j);
                        writer.write(e.className + "::" + e.methodName + "\n");
                    }
                }
                writer.close();
                ToastHelper.showSuccessToast(this, "Backup saved!");
            }
        } catch (Exception e) {
            ToastHelper.showErrorToast(this, "Backup failed: " + e.getMessage());
        }
    }
    
    private void doRestore(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                List<ProfileManager.GameProfile> restored = new ArrayList<ProfileManager.GameProfile>();
                String line;
                String name = null;
                List<ProfileManager.OffsetEntry> entries = new ArrayList<ProfileManager.OffsetEntry>();
                
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.equals("|||")) {
                        if (name != null && !entries.isEmpty()) {
                            restored.add(new ProfileManager.GameProfile(name, new ArrayList<ProfileManager.OffsetEntry>(entries)));
                        }
                        name = null;
                        entries.clear();
                    } else if (name == null && !line.isEmpty()) {
                        name = line;
                    } else if (name != null && line.contains("::")) {
                        String[] parts = line.split("::");
                        if (parts.length >= 2) {
                            entries.add(new ProfileManager.OffsetEntry(parts[0], parts[1]));
                        }
                    }
                }
                
                if (name != null && !entries.isEmpty()) {
                    restored.add(new ProfileManager.GameProfile(name, new ArrayList<ProfileManager.OffsetEntry>(entries)));
                }
                
                reader.close();
                
                if (!restored.isEmpty()) {
                    for (ProfileManager.GameProfile p : restored) {
                        profileManager.saveProfile(p);
                    }
                    loadProfiles();
                    ToastHelper.showSuccessToast(this, "Restored " + restored.size() + " profiles!");
                } else {
                    ToastHelper.showErrorToast(this, "No valid profiles found in file");
                }
            }
        } catch (Exception e) {
            ToastHelper.showErrorToast(this, "Restore failed: " + e.getMessage());
        }
    }
    
    private void doImportProfile(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String name = null;
                List<ProfileManager.OffsetEntry> entries = new ArrayList<ProfileManager.OffsetEntry>();
                String line;
                
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (name == null && !line.isEmpty()) {
                        name = line;
                    } else if (name != null && line.contains("::")) {
                        String[] parts = line.split("::");
                        if (parts.length >= 2) {
                            entries.add(new ProfileManager.OffsetEntry(parts[0], parts[1]));
                        }
                    }
                }
                reader.close();
                
                if (name != null && !entries.isEmpty()) {
                    profileManager.saveProfile(new ProfileManager.GameProfile(name, entries));
                    loadProfiles();
                    ToastHelper.showSuccessToast(this, "Imported: " + name + " (" + entries.size() + " offsets)");
                } else {
                    ToastHelper.showErrorToast(this, "Invalid profile file format");
                }
            }
        } catch (Exception e) {
            ToastHelper.showErrorToast(this, "Import failed: " + e.getMessage());
        }
    }
    
    private void clearForm() {
        edtProfileName.setText("");
        edtClassName.setText("");
        edtMethodName.setText("");
        currentEntries.clear();
        currentProfileName = null;
        isEditingProfile = false;
        updateEntriesView();
        loadProfiles();
    }
    
    private void addEntry() {
        String className = edtClassName.getText().toString().trim();
        String methodName = edtMethodName.getText().toString().trim();
        
        if (className.isEmpty() || methodName.isEmpty()) {
            Toast.makeText(this, "Enter class and method", Toast.LENGTH_SHORT).show();
            return;
        }
        
        currentEntries.add(new ProfileManager.OffsetEntry(className, methodName));
        edtClassName.setText("");
        edtMethodName.setText("");
        edtClassName.requestFocus();
        updateEntriesView();
    }
    
    private void updateEntriesView() {
        entriesLayout.removeAllViews();
        
        if (currentEntries.isEmpty()) {
            TextView hint = new TextView(this);
            hint.setText("No entries added yet");
            hint.setTextColor(0xFF606060);
            hint.setTextSize(14);
            hint.setGravity(android.view.Gravity.CENTER);
            hint.setPadding(16, 20, 16, 20);
            entriesLayout.addView(hint);
            return;
        }
        
        for (int i = 0; i < currentEntries.size(); i++) {
            final ProfileManager.OffsetEntry entry = currentEntries.get(i);
            final int index = i;
            
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(12, 10, 12, 10);
            row.setBackgroundResource(R.drawable.entry_bg);
            
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 4, 0, 4);
            row.setLayoutParams(params);
            
            TextView num = new TextView(this);
            num.setText(String.valueOf(i + 1));
            num.setTextColor(0xFF7C4DFF);
            num.setTextSize(14);
            num.setPadding(0, 0, 12, 0);
            num.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ));
            
            TextView text = new TextView(this);
            text.setText(entry.className + "." + entry.methodName);
            text.setTextColor(0xFFE0E0E0);
            text.setTextSize(14);
            text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            
            Button btnRemove = new Button(this);
            btnRemove.setText("X");
            btnRemove.setTextColor(0xFFFFFFFF);
            btnRemove.setTextSize(12);
            btnRemove.setBackgroundColor(0xFFB71C1C);
            btnRemove.setPadding(12, 6, 12, 6);
            btnRemove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentEntries.remove(index);
                    updateEntriesView();
                }
            });
            
            row.addView(num);
            row.addView(text);
            row.addView(btnRemove);
            entriesLayout.addView(row);
        }
    }
    
    private void saveProfile() {
        String name = edtProfileName.getText().toString().trim();
        
        if (name.isEmpty()) {
            Toast.makeText(this, "Enter profile name", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (currentEntries.isEmpty()) {
            Toast.makeText(this, "Add at least one offset entry", Toast.LENGTH_SHORT).show();
            return;
        }
        
        ProfileManager.GameProfile profile = new ProfileManager.GameProfile(name, currentEntries);
        profileManager.saveProfile(profile);
        
        if (isEditingProfile) {
            Toast.makeText(this, "Profile updated!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Profile saved!", Toast.LENGTH_SHORT).show();
        }
        
        clearForm();
    }
    
    private void loadProfiles() {
        profiles = profileManager.getAllProfiles();
        if (profiles == null) {
            profiles = new ArrayList<ProfileManager.GameProfile>();
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }
    
    private void loadProfile(int position) {
        ProfileManager.GameProfile profile = profiles.get(position);
        edtProfileName.setText(profile.name);
        currentProfileName = profile.name;
        currentEntries.clear();
        currentEntries.addAll(profile.entries);
        isEditingProfile = true;
        updateEntriesView();
        
        Toast.makeText(this, "Editing: " + profile.name, Toast.LENGTH_SHORT).show();
        
        edtProfileName.requestFocus();
        listView.smoothScrollToPosition(0);
    }
    
    private void deleteProfile(int position) {
        ProfileManager.GameProfile profile = profiles.get(position);
        profileManager.deleteProfile(profile.name);
        
        if (currentProfileName != null && currentProfileName.equals(profile.name)) {
            clearForm();
        }
        
        loadProfiles();
        Toast.makeText(this, "Profile deleted", Toast.LENGTH_SHORT).show();
    }
    
    private void exportProfile(int position) {
        ProfileManager.GameProfile profile = profiles.get(position);
        Intent result = new Intent();
        result.putExtra("profile_name", profile.name);
        
        StringBuilder entries = new StringBuilder();
        for (int i = 0; i < profile.entries.size(); i++) {
            ProfileManager.OffsetEntry e = profile.entries.get(i);
            if (i > 0) entries.append(",");
            entries.append(e.className).append("::").append(e.methodName);
        }
        result.putExtra("entries", entries.toString());
        setResult(Activity.RESULT_OK, result);
        finish();
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                if (requestCode == IMPORT_PROFILE_REQUEST) {
                    doImportProfile(uri);
                } else if (requestCode == BACKUP_PROFILES_REQUEST) {
                    doBackup(uri);
                } else if (requestCode == RESTORE_PROFILES_REQUEST) {
                    doRestore(uri);
                }
            }
        }
    }
    
    class ProfileAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return profiles == null ? 0 : profiles.size();
        }
        
        @Override
        public Object getItem(int position) {
            return profiles.get(position);
        }
        
        @Override
        public long getItemId(int position) {
            return position;
        }
        
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LinearLayout layout = new LinearLayout(ProfileManagerActivity.this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 14, 16, 14);
            layout.setBackgroundResource(R.drawable.profile_card_bg);
            
            final ProfileManager.GameProfile profile = profiles.get(position);
            
            LinearLayout headerRow = new LinearLayout(ProfileManagerActivity.this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);
            headerRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
            
            TextView name = new TextView(ProfileManagerActivity.this);
            name.setText(profile.name);
            name.setTextColor(0xFF7C4DFF);
            name.setTextSize(17);
            name.getPaint().setFakeBoldText(true);
            name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            
            TextView count = new TextView(ProfileManagerActivity.this);
            count.setText(profile.entries.size() + " offsets");
            count.setTextColor(0xFF808080);
            count.setTextSize(13);
            
            headerRow.addView(name);
            headerRow.addView(count);
            
            LinearLayout entriesList = new LinearLayout(ProfileManagerActivity.this);
            entriesList.setOrientation(LinearLayout.VERTICAL);
            entriesList.setPadding(0, 8, 0, 8);
            
            int maxShow = Math.min(profile.entries.size(), 3);
            for (int i = 0; i < maxShow; i++) {
                ProfileManager.OffsetEntry e = profile.entries.get(i);
                TextView entryText = new TextView(ProfileManagerActivity.this);
                entryText.setText("  " + e.className + "." + e.methodName);
                entryText.setTextColor(0xFFB0B0B0);
                entryText.setTextSize(13);
                entryText.setPadding(0, 3, 0, 3);
                entriesList.addView(entryText);
            }
            
            if (profile.entries.size() > 3) {
                TextView more = new TextView(ProfileManagerActivity.this);
                more.setText("  +" + (profile.entries.size() - 3) + " more...");
                more.setTextColor(0xFF606060);
                more.setTextSize(12);
                more.setPadding(0, 3, 0, 3);
                entriesList.addView(more);
            }
            
            LinearLayout buttons = new LinearLayout(ProfileManagerActivity.this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            
            Button btnLoad = new Button(ProfileManagerActivity.this);
            btnLoad.setText("EDIT");
            btnLoad.setTextColor(0xFFFFFFFF);
            btnLoad.setTextSize(12);
            btnLoad.setBackgroundColor(0xFF424242);
            btnLoad.setPadding(12, 8, 12, 8);
            btnLoad.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            LinearLayout.LayoutParams loadParams = (LinearLayout.LayoutParams) btnLoad.getLayoutParams();
            loadParams.setMargins(0, 0, 6, 0);
            btnLoad.setLayoutParams(loadParams);
            btnLoad.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadProfile(position);
                }
            });
            
            Button btnExport = new Button(ProfileManagerActivity.this);
            btnExport.setText("USE");
            btnExport.setTextColor(0xFFFFFFFF);
            btnExport.setTextSize(12);
            btnExport.setBackgroundColor(0xFF00E676);
            btnExport.setPadding(12, 8, 12, 8);
            btnExport.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            LinearLayout.LayoutParams exportParams = (LinearLayout.LayoutParams) btnExport.getLayoutParams();
            exportParams.setMargins(6, 0, 6, 0);
            btnExport.setLayoutParams(exportParams);
            btnExport.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    exportProfile(position);
                }
            });
            
            Button btnDelete = new Button(ProfileManagerActivity.this);
            btnDelete.setText("DEL");
            btnDelete.setTextColor(0xFFFFFFFF);
            btnDelete.setTextSize(12);
            btnDelete.setBackgroundColor(0xFFB71C1C);
            btnDelete.setPadding(12, 8, 12, 8);
            btnDelete.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            LinearLayout.LayoutParams delParams = (LinearLayout.LayoutParams) btnDelete.getLayoutParams();
            delParams.setMargins(6, 0, 0, 0);
            btnDelete.setLayoutParams(delParams);
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteProfile(position);
                }
            });
            
            buttons.addView(btnLoad);
            buttons.addView(btnExport);
            buttons.addView(btnDelete);
            
            layout.addView(headerRow);
            layout.addView(entriesList);
            layout.addView(buttons);
            
            return layout;
        }
    }
}
