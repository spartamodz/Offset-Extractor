package com.example.application.util;

import android.content.ContentResolver;
import android.net.Uri;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SoInfoExtractor {
    
    private static final int BUFFER_SIZE = 8192;
    private static final int SEARCH_LIMIT = 50 * 1024 * 1024;
    
    private Uri fileUri;
    private ContentResolver contentResolver;
    private String lastError;
    
    public SoInfoExtractor(ContentResolver contentResolver, Uri fileUri) {
        this.contentResolver = contentResolver;
        this.fileUri = fileUri;
    }
    
    public SoInfoResult extractInfo() {
        if (fileUri == null) {
            lastError = "File URI not set";
            return null;
        }
        
        if (contentResolver == null) {
            lastError = "ContentResolver not available";
            return null;
        }
        
        InputStream inputStream = null;
        try {
            inputStream = contentResolver.openInputStream(fileUri);
            if (inputStream == null) {
                lastError = "Cannot open file";
                return null;
            }
            
            String unityVersion = null;
            String il2cppVersion = null;
            String architecture = null;
            int pointerSize = 0;
            
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8), BUFFER_SIZE);
            
            StringBuilder buffer = new StringBuilder(8192);
            int charsRead;
            long totalRead = 0;
            
            while ((charsRead = reader.read()) != -1) {
                if (totalRead > SEARCH_LIMIT) break;
                totalRead++;
                
                char ch = (char) charsRead;
                if (ch >= 32 && ch <= 126) {
                    buffer.append(ch);
                } else {
                    if (buffer.length() > 0) {
                        String text = buffer.toString();
                        
                        if (unityVersion == null) {
                            unityVersion = extractUnityVersion(text);
                        }
                        
                        if (il2cppVersion == null) {
                            il2cppVersion = extractIl2cppVersion(text);
                        }
                        
                        buffer.setLength(0);
                    }
                }
            }
            
            architecture = detectArchitecture(fileUri);
            pointerSize = architecture != null && architecture.contains("64") ? 8 : 4;
            
            reader.close();
            
            return new SoInfoResult(
                unityVersion != null ? unityVersion : "Not found",
                il2cppVersion != null ? il2cppVersion : "Not found",
                architecture != null ? architecture : "Unknown",
                pointerSize,
                "libil2cpp.so"
            );
            
        } catch (IOException e) {
            lastError = "Error: " + e.getMessage();
            return null;
        } finally {
            if (inputStream != null) {
                try { inputStream.close(); } catch (IOException e) { }
            }
        }
    }
    
    private String extractUnityVersion(String text) {
        Pattern pattern = Pattern.compile("UnityPlayer\\.so.*?(\\d{4}\\.\\d\\.\\d+[a-z]?\\d*)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        
        pattern = Pattern.compile("Unity\\s+v?(\\d{4}\\.\\d\\.\\d+[a-z]?\\d*)", Pattern.CASE_INSENSITIVE);
        matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        
        pattern = Pattern.compile("Built from.*?(\\d{4}\\.\\d\\.\\d+[a-z]?\\d*)", Pattern.CASE_INSENSITIVE);
        matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        
        return null;
    }
    
    private String extractIl2cppVersion(String text) {
        Pattern pattern = Pattern.compile("IL2CPP.*?(\\d+\\.\\d+\\.\\d+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        
        pattern = Pattern.compile("il2cpp.*?(\\d{4}\\.\\d\\.\\d+[a-z]?\\d*)", Pattern.CASE_INSENSITIVE);
        matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        
        return null;
    }
    
    private String detectArchitecture(Uri uri) {
        InputStream is = null;
        try {
            is = contentResolver.openInputStream(uri);
            if (is == null) return null;
            
            byte[] header = new byte[20];
            int read = is.read(header);
            if (read < 20) return null;
            
            if (header[0] == 0x7F && header[1] == 'E' && header[2] == 'L' && header[3] == 'F') {
                int eiClass = header[4];
                int eiData = header[5];
                
                String endian = eiData == 1 ? "LE" : "BE";
                String bits = eiClass == 2 ? "64-bit" : (eiClass == 1 ? "32-bit" : "Unknown");
                
                int machine = ((header[19] & 0xFF) << 8) | (header[18] & 0xFF);
                String arch = "Unknown";
                
                if (machine == 0x003E) arch = "x86_64";
                else if (machine == 0x0003 || machine == 0x0028) arch = "ARM";
                else if (machine == 0x00B7) arch = "ARM64";
                else if (machine == 0x014C) arch = "x86";
                else arch = "0x" + Integer.toHexString(machine);
                
                return arch + " " + bits + " (" + endian + ")";
            }
        } catch (IOException e) {
        } finally {
            if (is != null) {
                try { is.close(); } catch (IOException e) { }
            }
        }
        return null;
    }
    
    public String getLastError() {
        return lastError;
    }
    
    public static class SoInfoResult {
        public final String unityVersion;
        public final String il2cppVersion;
        public final String architecture;
        public final int pointerSize;
        public final String fileName;
        
        public SoInfoResult(String unityVersion, String il2cppVersion, String architecture, 
                          int pointerSize, String fileName) {
            this.unityVersion = unityVersion;
            this.il2cppVersion = il2cppVersion;
            this.architecture = architecture;
            this.pointerSize = pointerSize;
            this.fileName = fileName;
        }
        
        public String getFormattedInfo() {
            StringBuilder sb = new StringBuilder(256);
            sb.append("FILE: ").append(fileName).append('\n');
            sb.append("UNITY: ").append(unityVersion).append('\n');
            sb.append("IL2CPP: ").append(il2cppVersion).append('\n');
            sb.append("ARCH: ").append(architecture).append('\n');
            sb.append("PTR SIZE: ").append(pointerSize).append(" bytes");
            return sb.toString();
        }
        
        public boolean hasUnityVersion() {
            return unityVersion != null && !unityVersion.equals("Not found");
        }
    }
}
