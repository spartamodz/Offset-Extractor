package com.example.application.util;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ToastHelper {
    
    public static void showToast(Context context, String message) {
        showToast(context, message, Toast.LENGTH_SHORT);
    }
    
    public static void showLongToast(Context context, String message) {
        showToast(context, message, Toast.LENGTH_LONG);
    }
    
    public static void showToast(Context context, String message, int duration) {
        Toast toast = new Toast(context);
        toast.setDuration(duration);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
        
        LinearLayout layout = new LinearLayout(context);
        layout.setPadding(48, 32, 48, 32);
        layout.setOrientation(LinearLayout.VERTICAL);
        
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#2D2D2D"));
        background.setCornerRadius(16);
        background.setStroke(2, Color.parseColor("#7C4DFF"));
        layout.setBackground(background);
        
        TextView textView = new TextView(context);
        textView.setText(message);
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTextSize(15);
        textView.setGravity(Gravity.CENTER);
        
        layout.addView(textView);
        toast.setView(layout);
        toast.show();
    }
    
    public static void showSuccessToast(Context context, String message) {
        Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
        
        LinearLayout layout = new LinearLayout(context);
        layout.setPadding(48, 32, 48, 32);
        layout.setOrientation(LinearLayout.VERTICAL);
        
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#1B5E20"));
        background.setCornerRadius(16);
        background.setStroke(2, Color.parseColor("#00E676"));
        layout.setBackground(background);
        
        TextView textView = new TextView(context);
        textView.setText("OK: " + message);
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTextSize(15);
        textView.setGravity(Gravity.CENTER);
        
        layout.addView(textView);
        toast.setView(layout);
        toast.show();
    }
    
    public static void showErrorToast(Context context, String message) {
        Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
        
        LinearLayout layout = new LinearLayout(context);
        layout.setPadding(48, 32, 48, 32);
        layout.setOrientation(LinearLayout.VERTICAL);
        
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#B71C1C"));
        background.setCornerRadius(16);
        background.setStroke(2, Color.parseColor("#FF5252"));
        layout.setBackground(background);
        
        TextView textView = new TextView(context);
        textView.setText("Error: " + message);
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTextSize(15);
        textView.setGravity(Gravity.CENTER);
        
        layout.addView(textView);
        toast.setView(layout);
        toast.show();
    }
    
    public static void showInfoToast(Context context, String message) {
        Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
        
        LinearLayout layout = new LinearLayout(context);
        layout.setPadding(48, 32, 48, 32);
        layout.setOrientation(LinearLayout.VERTICAL);
        
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#0D47A1"));
        background.setCornerRadius(16);
        background.setStroke(2, Color.parseColor("#448AFF"));
        layout.setBackground(background);
        
        TextView textView = new TextView(context);
        textView.setText("Info: " + message);
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTextSize(15);
        textView.setGravity(Gravity.CENTER);
        
        layout.addView(textView);
        toast.setView(layout);
        toast.show();
    }
}
