package com.example.application.util;

import android.content.ContentResolver;
import android.net.Uri;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OffsetFinder {
    
    private static final int BUFFER_SIZE = 8192;
    private static final Pattern CLASS_PATTERN = Pattern.compile("(?:class|struct)\\s+(\\w+)");
    private static final Pattern RVA_PATTERN = Pattern.compile("// RVA: (0x[0-9A-Fa-f]+)");
    
    private Uri dumpFileUri;
    private ContentResolver contentResolver;
    private String lastError;
    private boolean isCancelled;
    
    public OffsetFinder(ContentResolver contentResolver, Uri dumpFileUri) {
        this.contentResolver = contentResolver;
        this.dumpFileUri = dumpFileUri;
        this.isCancelled = false;
    }
    
    public void cancel() {
        isCancelled = true;
    }
    
    public OffsetResult findOffset(String className, String methodName) {
        if (dumpFileUri == null) {
            lastError = "Dump file URI not set";
            return null;
        }
        
        if (contentResolver == null) {
            lastError = "ContentResolver not available";
            return null;
        }
        
        if (className == null || className.trim().isEmpty()) {
            lastError = "Class name is required";
            return null;
        }
        
        if (methodName == null || methodName.trim().isEmpty()) {
            lastError = "Method name is required";
            return null;
        }
        
        // Normalize inputs - remove spaces, trim, lowercase
        String normalizedClass = className.toLowerCase().trim().replaceAll("\\s+", "");
        String normalizedMethod = methodName.toLowerCase().trim().replaceAll("\\s+", "");
        
        // Create method variations for flexible matching
        String[] methodVariations = new String[] {
            normalizedMethod,
            "get_" + normalizedMethod,
            "set_" + normalizedMethod,
            normalizedMethod.replace("_", ""),
        };
        
        String lastRva = null;
        String currentClass = null;
        String foundSignature = null;
        String returnType = "Unknown";
        long linesProcessed = 0;
        
        InputStream inputStream = null;
        BufferedReader reader = null;
        
        try {
            inputStream = contentResolver.openInputStream(dumpFileUri);
            if (inputStream == null) {
                lastError = "Cannot open file stream";
                return null;
            }
            
            // Use larger buffer for better performance with large files
            reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8), BUFFER_SIZE);
            StringBuilder lineBuffer = new StringBuilder(1024);
            int c;
            char prevChar = 0;
            
            while ((c = reader.read()) != -1) {
                if (isCancelled) {
                    lastError = "Search cancelled";
                    return null;
                }
                
                char ch = (char) c;
                
                if (ch == '\n') {
                    linesProcessed++;
                    String line = lineBuffer.toString().trim();
                    lineBuffer.setLength(0);
                    
                    if (line.isEmpty()) {
                        prevChar = ch;
                        continue;
                    }
                    
                    // Fast check for RVA comment (very common)
                    if (line.length() > 10 && line.charAt(0) == '/' && line.charAt(1) == '/') {
                        if (line.contains("RVA:")) {
                            int rvaStart = line.indexOf("0x");
                            if (rvaStart > 0) {
                                int rvaEnd = rvaStart + 10;
                                if (rvaEnd <= line.length()) {
                                    lastRva = line.substring(rvaStart, Math.min(rvaEnd, line.length()));
                                }
                            }
                        }
                        prevChar = ch;
                        continue;
                    }
                    
                    // Check for class/struct definition
                    if (line.contains("class ") || line.contains("struct ")) {
                        Matcher classMatcher = CLASS_PATTERN.matcher(line);
                        if (classMatcher.find()) {
                            currentClass = classMatcher.group(1).toLowerCase();
                        }
                        prevChar = ch;
                        continue;
                    }
                    
                    // Check for method match in current class
                    if (currentClass != null && currentClass.equals(normalizedClass)) {
                        if (line.indexOf('(') >= 0 && line.indexOf(')') >= 0) {
                            String lineLower = line.toLowerCase();
                            
                            for (String methodVar : methodVariations) {
                                if (lineLower.indexOf(methodVar) >= 0) {
                                    foundSignature = extractCodePart(line);
                                    returnType = extractReturnTypeFast(line, normalizedMethod);
                                    
                                    return new OffsetResult(
                                        className,
                                        methodName,
                                        foundSignature,
                                        returnType,
                                        lastRva != null ? lastRva : "NOT FOUND"
                                    );
                                }
                            }
                        }
                    }
                    
                    prevChar = ch;
                } else {
                    lineBuffer.append(ch);
                }
            }
            
            lastError = "Offset not found after scanning " + linesProcessed + " lines";
            return null;
            
        } catch (IOException e) {
            lastError = "Error reading file: " + e.getMessage();
            return null;
        } finally {
            if (reader != null) {
                try { reader.close(); } catch (IOException e) { }
            }
            if (inputStream != null) {
                try { inputStream.close(); } catch (IOException e) { }
            }
        }
    }
    
    private String extractCodePart(String line) {
        int commentIndex = line.indexOf("//");
        if (commentIndex > 0) {
            return line.substring(0, commentIndex).trim();
        }
        return line.trim();
    }
    
    private String extractReturnTypeFast(String line, String methodName) {
        int methodIdx = line.toLowerCase().indexOf(methodName);
        if (methodIdx <= 0) return "Unknown";
        
        int searchStart = methodIdx - 1;
        while (searchStart >= 0 && Character.isWhitespace(line.charAt(searchStart))) {
            searchStart--;
        }
        
        if (searchStart < 0) return "Unknown";
        
        int typeEnd = searchStart + 1;
        int typeStart = searchStart;
        
        while (typeStart >= 0) {
            char ch = line.charAt(typeStart);
            if (Character.isWhitespace(ch) || ch == '<' || ch == '>') {
                if (typeStart < typeEnd) {
                    break;
                }
                typeStart++;
                break;
            }
            typeStart--;
        }
        
        if (typeStart < 0) typeStart = 0;
        if (typeStart >= typeEnd) return "Unknown";
        
        return line.substring(typeStart, typeEnd).trim();
    }
    
    public String getLastError() {
        return lastError;
    }
    
    public static class OffsetResult {
        public final String className;
        public final String methodName;
        public final String signature;
        public final String returnType;
        public final String rva;
        
        public OffsetResult(String className, String methodName, String signature, 
                          String returnType, String rva) {
            this.className = className;
            this.methodName = methodName;
            this.signature = signature;
            this.returnType = returnType;
            this.rva = rva;
        }
        
        public String getFormattedInfo() {
            StringBuilder sb = new StringBuilder(256);
            sb.append("CLASS: ").append(className).append('\n');
            sb.append("METHOD: ").append(methodName).append('\n');
            sb.append("SIGNATURE: ").append(signature).append('\n');
            sb.append("TYPE: ").append(returnType).append('\n');
            sb.append("OFFSET: ").append(rva);
            return sb.toString();
        }
    }
}
